export default {
	  // basePath: 'http://www.qingting.com/Api',
    // basePath: 'http://www.wanneng.com/Api',
	  basePath: 'https://t.qingtingtech.com/Api',
    publicid: 84
}